// Simple console message

console.log("Welcome to Nivash K's portfolio!");